#importing the necessary libraries
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

# importing all libraries to run rasa and zomato.py
from rasa.constants import DEFAULT_DATA_PATH
from rasa_sdk import Action, Tracker
from rasa_sdk.events import AllSlotsReset, SlotSet, Restarted
import zomatopy
import json


import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


### Returing the list of restaurants
class ActionRestaurantSearch(Action):
    def name(self):
        return 'action_restaurant_search'                                # function to be used for sending email
        
    def run(self, dispatcher, tracker, domain):        
        count = 0                                                        #initiating the restaurant count
        config={ "user_key":"acd9f5ef709038796d4b2cf3549fc8d8"}          #assigning the key
        zomato = zomatopy.initialize_app(config)                         #initializing the key
        location = tracker.get_slot('location')                          # setting the slot for location
        cuisine = tracker.get_slot('cuisine')                            # setting the slot for cuisine
        budget = tracker.get_slot('budget')                              # setting the slot for budget
        location_info=zomato.get_location(location, 1)                   # getting the location for zomatopy
        d1 = json.loads(location_info)                                   #loading json
        lat=d1["location_suggestions"][0]["latitude"]                    #setting lat
        lon=d1["location_suggestions"][0]["longitude"]                   #setting lon
        cuisine_info={'Chinese':25,'Italian':55,'North Indian':50,'South Indian':85,'American':1,'Mexican':73}    #defining the cuisines
        budget_info = {'Lesser than 300':1,'300 to 700':2,'More than 700':3}                                      #defining the budget
        output=zomato.restaurant_search("", lat, lon, str(cuisine_info.get(cuisine)), 50000)                      # fetching output
        d = json.loads(output)   
        response="There you have the top rated restaurants:"+"\n"                                                 # storing the responses for output
        if d['results_found'] == 0:                                                                               #if no result found
            response= "No restaurant found for your search" 
            dispatcher.utter_message(response)
        else:                                                                                                     # if result found
            for restaurant in sorted(d['restaurants'], key=lambda x: x['restaurant']['user_rating']['aggregate_rating'], reverse=True): 
                #Fetching the best 10 restaurants from lookup
                
                #if budget cost is less than Rs 300
                if((budget_info.get(budget) == 1) and (restaurant['restaurant']['average_cost_for_two'] < 300) and (count < 10)):
                    response=response+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+ " has been rated "+ restaurant['restaurant']['user_rating']['aggregate_rating']+"\n"
                    count = count + 1                                                                             #increasing the count
                #if budget cost is betwen Rs 300 and Rs 700
                elif((budget_info.get(budget) == 2) and (restaurant['restaurant']['average_cost_for_two'] >= 300) and (restaurant['restaurant']['average_cost_for_two'] <= 700) and (count < 10)):
                    response=response+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+ " has been rated "+ restaurant['restaurant']['user_rating']['aggregate_rating']+"\n"
                    count = count + 1                                                                             #increasing the count
                #if budget cost is more than 700                    
                elif((budget_info.get(budget) == 3) and (restaurant['restaurant']['average_cost_for_two'] > 700) and (count < 10)):
                    response=response+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+ " has been rated "+ restaurant['restaurant']['user_rating']['aggregate_rating']+"\n"
                    count = count + 1                                                             #increasing the count
                if(count==5):
                    dispatcher.utter_message(response)                                            # showing the best 5 restaurants
        if(count<5 and count>0):                                                                  # showing the best restaurants
            dispatcher.utter_message(response)
        if(count==0):                                                                             # if no restaurant found
            response = "Ah, nothing found. Would you like to search for some other restaurants?"
            dispatcher.utter_message(response)
        return [SlotSet('emailbody',response)]                                                    # returning the output from the function

### Checking whether the location entered is correct or not
class ActionLocationCheck(Action):

    def name(self):
        return 'action_location_check'                                                            # function to be used for checking location

    def run(self, dispatcher, tracker, domain):
        location = tracker.get_slot('location')                                                   # setting the slot for location
        
        #Explicitly writing all the locations i.e. Tier - I and II cities
        location_cities=['Ahmedabad','Bangalore','Chennai','Delhi','Hyderabad','Kolkata','Mumbai','Pune','Agra','Ajmer','Aligarh','Allahabad','Amravati',
                         'Amritsar','Asansol','Bareilly','Belgaum','Bhavnagar','Bhiwandi','Bhopal','Bhubaneswar','Bikaner','Chandigarh','Coimbatore',
                         'Nagpur','Cuttack','Dehradun','Dhanbad','Durgapur','Erode','Faridabad','Firozabad','Gulbarga','Guntur','Gwalior',
                          'Gurgaon','Guwahati','Indore','Jabalpur','Jaipur','Jalandhar','Jammu','Jamnagar','Jamshedpur','Jhansi','Jodhpur',
                          'Kakinada','Kannur','Kanpur','Kochi','Kottayam','Kolhapur','Kollam','Kozhikode','Kurnool','Lucknow','Ludhiana','Madurai',
                          'Malappuram','Mathura','Goa','Mangalore','Meerut','Moradabad','Mysore','Nanded','Nashik','Nellore','Noida','Palakkad',
                          'Patna','Pondicherry','Raipur','Rajkot','Rajahmundry','Ranchi','Rourkela','Sangli','Siliguri','Solapur','Srinagar','Surat',
                            'Thiruvananthapuram','Thrissur','Tiruchirappalli','Tirunelveli','Tiruppur','Tiruvannamalai','Ujjain','Bijapur',
                            'Vadodara','Varanasi','Vijayawada','Visakhapatnam','Vellore','Warangal']
        
        # Writing the cities in lower case
        cities_lower=[x.lower() for x in location_cities]
        
        #Checking the location with list
        if location.lower() not in cities_lower:
            dispatcher.utter_message("Apologies, we are not operating in this city currently. Can you please specify some other location")
        return   

        
### Checking whether the cuisine entered is correct or not
class ActionCuisineCheck(Action):

    def name(self):
        return 'action_check_cuisine'                                                              # function to be used for checking location

    def run(self, dispatcher, tracker, domain):
        cuis = tracker.get_slot('cuisine')                                                      # setting the slot for cuisine
        
        # Explicitly specifying the cuisine prefernce        
        cuisine=['Chinese','Mexican','American','Italian','North Indian','South Indian']
        
        # Writing the cuisine in lower case
        cuisine_lower=[x.lower() for x in cuisine]
        
        #Checking the cuisine with list
        if cuis.lower() not in cuisine_lower:
            dispatcher.utter_message("Sorry, this is not a valid cuisine. Please enter a different cuisine")
        return   

### Returing the email sent to user        
class ActionSendEmailToUser(Action):

    def name(self):
        return 'action_email_send'                                                                 # function to be used for sending email

    def run(self, dispatcher, tracker, domain):
        try:
            from_user = 'foodiechatbot555@gmail.com'                                                   # created a new gmail id
            to_user = tracker.get_slot('email')                                                        # keeping track of email id enterted by user to get list
            password = 'upgrad123'                                                                     # password for email above
            server = smtplib.SMTP('smtp.gmail.com',587)                                                # setting the server code
            server.starttls()                                                                          # starting the TLS server
            server.login(from_user, password)                                                          # taking username and password to login to gmail id
            subject = 'Delightful restaurants from your own Foodie'                                    # adding subject for email
            msg = MIMEMultipart()                                                   
            msg['From'] = from_user                                                                    
            msg['TO'] = to_user
            msg['Subject'] = subject
            body = tracker.get_slot('emailbody')
            msg.attach(MIMEText(body,'plain'))
            text = msg.as_string()
            server.sendmail(from_user,to_user,text)                                                    # sending the mail to user entered mail id
            server.close()
            
        except Exception as e:
            dispatcher.utter_message("Sorry, this is not a valid email. Please enter a valid one")

        
    
 ### Starting the interactive session back again       
class ActionRestarted(Action): 	
	def name(self):
		return 'action_start_again'                                                                 # restarting the entire session
	def run(self, dispatcher, tracker, domain):
		return[Restarted()] 

 ### Resetting the slots to None
class ActionSlotReset(Action): 
	def name(self): 
		return 'action_reset_slot'                                                                  #resetting the slot
	def run(self, dispatcher, tracker, domain): 
		return[AllSlotsReset()]