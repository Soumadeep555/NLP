## interactive_story_1
* greet
 - utter_greet
* restaurant_search
 - utter_ask_location
* restaurant_search{"location": "Bangalore"}
 - slot{"location": "Bangalore"}
 - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
 - slot{"cuisine": "Mexican"}
 - action_restaurant_search
 - export
 
## interactive_story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search
    - action_restaurant_search
    - slot{"location": "Bangalore"}
    - utter_goodbye

## interactive_story_3
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Hyderabad"}
    - slot{"location": "Hyderabad"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Chinese"}
    - slot{"cuisine": "chinese"}
    - action_restaurant_search
    - slot{"location": "Hyderabad"}
* goodbye

## interactive_story_4
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget_for_two
* restaurant_search{"budget": "Lesser than 300"}
    - slot{"budget": "Lesser than 300"}
    - action_restaurant_search
* thanks
    - utter_goodbye
	
## interactive_story_5
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - utter_goodbye

## interactive_story_6
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMumbai Tiffin in 2345, 17th Cross, Opposite Water Tank, Sector 1, HSR, Bangalore has been rated 4.4\n And the average budget for two people is: 400\nAligarh House in 34/154 & 155, 1st Floor, 11th Cross Somasundrapalya, Sector 2, HSR, Bangalore has been rated 4.3\n And the average budget for two people is: 400\nAl-Bek in 349, 350, 1A/87, Dr Rajkumar Road, 6th Block, Rajaji Nagar Industrial Town, Rajajinagar, Bangalore has been rated 4.2\n And the average budget for two people is: 400\nKalingas in 399, 16th Main, N.S Palya, BTM, Bangalore has been rated 4.2\n And the average budget for two people is: 300\nGrill Biryanis in 9, Jalahalli Cross Circle, Jalahalli, Bangalore has been rated 4.1\n And the average budget for two people is: 500\nAl-Bek in 48/6, MKK Road, Near Sri Rampura Metro Station, Nagappa Block, Rajajinagar, Bangalore has been rated 4.1\n And the average budget for two people is: 400\nAl-Bek in 527, 1st Cross, Sampige Road, Malleshwaram, Bangalore has been rated 4.1\n And the average budget for two people is: 400\nZero Mile Punjab in 79/8, 1st Main, Muneshwara Nagar, Sector 6, HSR, Bangalore has been rated 4.0\n And the average budget for two people is: 400\nAl-Bek in 1, 80 Feet Road, Besides Florence School, RT Nagar, Bangalore has been rated 4.0\n And the average budget for two people is: 400\nAl-Bek in 9th Block, Opposite Jayadeva Hospital, Off Bannerghatta Road, Jayanagar, Bangalore has been rated 4.0\n And the average budget for two people is: 650\n"}
* thanks
    - utter_thanks
	

## interactive_story_7
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
	- action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
	- action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMumbai Tiffin in 2345, 17th Cross, Opposite Water Tank, Sector 1, HSR, Bangalore has been rated 4.4\n And the average budget for two people is: 400\nAligarh House in 34/154 & 155, 1st Floor, 11th Cross Somasundrapalya, Sector 2, HSR, Bangalore has been rated 4.3\n And the average budget for two people is: 400\nAl-Bek in 349, 350, 1A/87, Dr Rajkumar Road, 6th Block, Rajaji Nagar Industrial Town, Rajajinagar, Bangalore has been rated 4.2\n And the average budget for two people is: 400\nKalingas in 399, 16th Main, N.S Palya, BTM, Bangalore has been rated 4.2\n And the average budget for two people is: 300\nGrill Biryanis in 9, Jalahalli Cross Circle, Jalahalli, Bangalore has been rated 4.1\n And the average budget for two people is: 500\nAl-Bek in 48/6, MKK Road, Near Sri Rampura Metro Station, Nagappa Block, Rajajinagar, Bangalore has been rated 4.1\n And the average budget for two people is: 400\nAl-Bek in 527, 1st Cross, Sampige Road, Malleshwaram, Bangalore has been rated 4.1\n And the average budget for two people is: 400\nZero Mile Punjab in 79/8, 1st Main, Muneshwara Nagar, Sector 6, HSR, Bangalore has been rated 4.0\n And the average budget for two people is: 400\nAl-Bek in 1, 80 Feet Road, Besides Florence School, RT Nagar, Bangalore has been rated 4.0\n And the average budget for two people is: 400\nAl-Bek in 9th Block, Opposite Jayadeva Hospital, Off Bannerghatta Road, Jayanagar, Bangalore has been rated 4.0\n And the average budget for two people is: 650\n"}
* thanks
    - utter_thanks
	- action_start_again
	

## interactive_story_8
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Noida"}
    - slot{"location": "Noida"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nNona's Kitchen in A 224, Ground Floor, Supermart 1, DLF Phase 4, Gurgaon has been rated 4.6\nBukhara - ITC Maurya in ITC Maurya, Chanakyapuri, New Delhi has been rated 4.6\nGulati in 6, Pandara Road Market, New Delhi has been rated 4.5\nBaba's in Opposite Metro Pillar 200, Opposite Suncity, Sector 53,  Golf Course Road, Gurgaon has been rated 4.1\nBikkgane Biryani in SCO 6, HUDA Market, Sector 31, Gurgaon has been rated 4.0\nGaon in 7, Ground Floor, Shivalik Road, Opposite AXIS Bank Block C, Malviya Nagar, New Delhi has been rated 3.8\n"}
* goodbye
    - utter_goodbye

## interactive_story_9
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent
    - utter_goodbye

## interactive_story_10
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent    
* thanks
    - utter_goodbye

## interactive_story_11
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	
## interactive_story_12
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* refuse
    - utter_goodbye	
	

## interactive_story_12
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* refuse
    - utter_goodbye
	
	

## interactive_story_13
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* refuse
    - utter_goodbye
	
	
## interactive_story_14
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* refuse
    - utter_goodbye
	


## interactive_story_15
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* refuse
    - utter_goodbye

## interactive_story_16
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	
	
## interactive_story_17
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300-700"}
    - slot{"budget": "300-700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMomo I Am in RBD Cinema, 1st Floor, Sector 5, Salt Lake, Kolkata has been rated 4.9\n And the average budget for two people is: 550\nWTF! - Where's The Food in E-75, Sukant Nagar, Sector 4, Salt Lake, Kolkata has been rated 4.6\n And the average budget for two people is: 300\nMomo I Am in CD 18, Next To Kalyan Jewelers, City Centre 1, Sector 1, Salt Lake has been rated 4.5\n And the average budget for two people is: 550\nMomo I Am in 43 Ballygunge Gardens, Gariahat, Golpark, Kolkata has been rated 4.5\n And the average budget for two people is: 550\nOverdose in 23, Lake Terrace, Sarath Bose Road, Southern Avenue, Kolkata has been rated 4.5\n And the average budget for two people is: 550\nMomo I Am in Shop G-B, Ground Floor, Tarun Alo Apartment, Chinar Park has been rated 4.4\n And the average budget for two people is: 550\nMomo I Am in 195 C, Near Bandhan Bank, Lake Gardens, Kolkata has been rated 4.4\n And the average budget for two people is: 550\nBlu Orchid in C22, Sammilani Park, Survey Park Area, Ajoy Nagar, Kolkata has been rated 4.3\n And the average budget for two people is: 700\nDenzong Kitchen in 9A, Bikramgarh, Jadavpur, Kolkata has been rated 4.1\n And the average budget for two people is: 300\n"}
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again

## interactive_story_18
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300-700"}
    - slot{"budget": "300-700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMomo I Am in RBD Cinema, 1st Floor, Sector 5, Salt Lake, Kolkata has been rated 4.9\n And the average budget for two people is: 550\nWTF! - Where's The Food in E-75, Sukant Nagar, Sector 4, Salt Lake, Kolkata has been rated 4.6\n And the average budget for two people is: 300\nMomo I Am in CD 18, Next To Kalyan Jewelers, City Centre 1, Sector 1, Salt Lake has been rated 4.5\n And the average budget for two people is: 550\nMomo I Am in 43 Ballygunge Gardens, Gariahat, Golpark, Kolkata has been rated 4.5\n And the average budget for two people is: 550\nOverdose in 23, Lake Terrace, Sarath Bose Road, Southern Avenue, Kolkata has been rated 4.5\n And the average budget for two people is: 550\nMomo I Am in Shop G-B, Ground Floor, Tarun Alo Apartment, Chinar Park has been rated 4.4\n And the average budget for two people is: 550\nMomo I Am in 195 C, Near Bandhan Bank, Lake Gardens, Kolkata has been rated 4.4\n And the average budget for two people is: 550\nBlu Orchid in C22, Sammilani Park, Survey Park Area, Ajoy Nagar, Kolkata has been rated 4.3\n And the average budget for two people is: 700\nDenzong Kitchen in 9A, Bikramgarh, Jadavpur, Kolkata has been rated 4.1\n And the average budget for two people is: 300\n"}
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again


## interactive_story_19
* greet
    - utter_greet
* restaurant_search{"cuisine": "Italian", "location": "Ghazipur"}
    - slot{"cuisine": "Italian"}
    - slot{"location": "Ghazipur"}
    - action_location_check
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300-700"}
    - slot{"budget": "300-700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nLa Pino'z Pizza in Shop 24,Shankar Plaza, 80 feet road, Koramangala 4th Block, Bangalore has been rated 4.2\n And the average budget for two people is: 600\nVinny's in No 22,1st Floor ,MSR Nagar ITI layout, New BEL Road, Bangalore has been rated 4.1\n And the average budget for two people is: 700\n"}
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	
	
## interactive_story_20
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* refuse
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	

## interactive_story_21
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* refuse
    - utter_reconfirm
* refuse
    - utter_goodbye
	
## interactive_story_22
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* refuse
    - utter_reconfirm
* refuse
    - utter_goodbye	
	
## interactive_story_23
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	

## interactive_story_24
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* refuse
    - utter_goodbye
	

## interactive_story_25
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* refuse
    - utter_reconfirm
* refuse
    - utter_goodbye
	

## interactive_story_26
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* refuse
    - utter_reconfirm
* affirm
    - action_reset_slot
    - action_start_again
	
	
## interactive_story_27	
* greet
    - utter_greet
* restaurant_search{"location": "Ghazipur"}
    - slot{"location": "Ghazipur"}
    - action_location_check
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
	- utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300-700"}
    - slot{"budget": "300-700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nLa Pino'z Pizza in Shop 24,Shankar Plaza, 80 feet road, Koramangala 4th Block, Bangalore has been rated 4.2\n And the average budget for two people is: 600\nVinny's in No 22,1st Floor ,MSR Nagar ITI layout, New BEL Road, Bangalore has been rated 4.1\n And the average budget for two people is: 700\n"}
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	

## interactive_story_28	
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
	- utter_ask_cuisine
* restaurant_search{"cuisine": "Mughlai"}
    - slot{"cuisine": "Mughlai"}
    - action_check_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_check_cuisine  
    - utter_ask_budget_for_two	
* restaurant_search{"budget": "300-700"}
    - slot{"budget": "300-700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nLa Pino'z Pizza in Shop 24,Shankar Plaza, 80 feet road, Koramangala 4th Block, Bangalore has been rated 4.2\n And the average budget for two people is: 600\nVinny's in No 22,1st Floor ,MSR Nagar ITI layout, New BEL Road, Bangalore has been rated 4.1\n And the average budget for two people is: 700\n"}
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	
	

## interactive_story_29	
* greet
    - utter_greet
* restaurant_search{"location": "Ghazipur"}
    - slot{"location": "Ghazipur"}
    - action_location_check
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
	- utter_ask_cuisine
* restaurant_search{"cuisine": "Mughlai"}
    - slot{"cuisine": "Mughlai"}
    - action_check_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300-700"}
    - slot{"budget": "300-700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nLa Pino'z Pizza in Shop 24,Shankar Plaza, 80 feet road, Koramangala 4th Block, Bangalore has been rated 4.2\n And the average budget for two people is: 600\nVinny's in No 22,1st Floor ,MSR Nagar ITI layout, New BEL Road, Bangalore has been rated 4.1\n And the average budget for two people is: 700\n"}
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	
	

## interactive_story_30	
* greet
    - utter_greet
* restaurant_search{"location": "Bengaluru"}
    - slot{"location": "Bangalore"}
    - action_location_check
	- utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300-700"}
    - slot{"budget": "300-700"}
    - action_restaurant_search
    - slot{"emailbody": "Showing you top rated restaurants:\nLa Pino'z Pizza in Shop 24,Shankar Plaza, 80 feet road, Koramangala 4th Block, Bangalore has been rated 4.2\n And the average budget for two people is: 600\nVinny's in No 22,1st Floor ,MSR Nagar ITI layout, New BEL Road, Bangalore has been rated 4.1\n And the average budget for two people is: 700\n"}
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent 
    - utter_reconfirm
* affirm
    - action_reset_slot
	- action_start_again
	
## interactive_story_31
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "There you have the top rated restaurants:\nMeghana Foods in 52, 1st Floor, 33rd Cross, 4th Block, Jayanagar, Bangalore has been rated 4.5\nMeghana Foods in 124, KHB Colony, 1st Cross, Near Jyothi Nivas College, Koramangala 5th Block, Bangalore has been rated 4.4\nMuthashy's in 3, Brindavan Complex, 20th Main, Maruthi Nagar Main Road, 1st Stage, BTM Layout has been rated 4.4\nMeghana Foods Grand in 90/4, Above Sony Centre, Opposite Park Plaza, Outer Ring Road, Marathahalli, Bangalore has been rated 4.3\neat.fit in 32/2G, NCPR Industrial Layout, Doddanakundi Industrial Area 2, Seetharampalya, Hoodi, Whitefield, Bangalore has been rated 4.3\nSharief Bhai in 66, Ground Floor, JNC Road, Koramangala 5th Block, Bangalore has been rated 4.3\neat.fit in 16, 1st Main Road, Muneswara Nagar, Sector 6, HSR, Bangalore has been rated 4.3\nKota Kachori in 635, 100 Feet Road, Koramangala 6th Block, Bangalore has been rated 4.2\neat.fit in 96, 29th Main, 23rd Cross, 2nd Stage, BTM, Bangalore has been rated 4.2\nKabab Magic in 1548, East End Circle, 9th Block, Jayanagar, Bangalore has been rated 4.1\n"}
* thanks
    - utter_email_confirmation
* affirm
    - utter_ask_email
* ask_email{"email": "abhinav4972@gmail.com"}
    - slot{"email": "abhinav4972@gmail.com"}
    - action_email_send
    - utter_email_sent
    - utter_reconfirm
* affirm
    - action_reset_slot
    - reset_slots
    - action_start_again

## interactive_story_32
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Kolkata"}
    - slot{"location": "Kolkata"}
    - action_location_check
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_check_cuisine
    - utter_ask_budget_for_two
* restaurant_search{"budget": "300 to 700"}
    - slot{"budget": "300 to 700"}
    - action_restaurant_search
    - slot{"emailbody": "There you have the top rated restaurants:\nZam Zam in 28/A, Syed Amir Ali Avenue, Park Circus Area, Kolkata has been rated 4.4\nMama Mia! in 59, Ballygunge Circular Road, Ballygunge, Kolkata has been rated 4.3\nHaji Saheb in 476, Diamond Harbour Road, Near Tram Depot Bazaar, Behala, Kolkata has been rated 4.2\nZam Zam in 9/1, Noor Ali Lane, Entally, Kolkata has been rated 4.2\nRoyal Indian Hotel in 147, Rabindra Sarani, Bara Bazar, Kolkata has been rated 4.2\nAminia in AS/317/10/-11 Block - B, Opposite Karnatake Bank, Sukantapally Chinar Park, Kolkata has been rated 4.2\nHotel Taaj in 99/8, Jessore Road, North Twenty Four Parganas, Nagerbazar, Kolkata has been rated 4.1\nGupta Brothers in 22, Himadri Apartment, Park Road, Ballygunge, Kolkata has been rated 4.1\nKFC in 20K, Park Street, Park Street Area, Kolkata has been rated 4.1\nThe Great Biryani Co. in MB 482, Majherpara, Bidhan Nagar, Near Bharat Gas Godown Mahisbathan, Sector 5, Salt Lake, Kolkata has been rated 4.1\n"}
* thanks
    - utter_reconfirm
* refuse
    - utter_goodbye
* goodbye
