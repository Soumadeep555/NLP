## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- yeah,sure
- yup
- cool
- okay
- of course
- absolutely
- certainly
- totally
- ya
- okie dokie
- alright
- sounds good
- sure thing
- aye
- uh huh
- sure
- fine
- confirm
- perfect
- hmm
- i agree
- k
- done
- accepted
- amazing

## intent:goodbye
- bye
- goodbye
- good bye
- end
- farewell
- Bye bye
- have a good one
- bbye
- see you later
- good talking to you
- take care
- nice talking to you
- catch you later
- talk to you later
- gotta run
- gotta go
- until tomorrow
- see ya!
- ciao
- adios
- sayonara
- see you soon

## intent:greet
- hey
- howdy
- hey there
- hello
- good morning
- good evening
- dear sir
- hi
- good afternoon
- hope you are doing good
- yo
- hi there
- good to see you
- long time no see
- it's been long
- greetings
- hi pal
- helloo
- hi it's me
- hi friend
- hey dude!
- Nice to meet you!
- Look who it is!
- hey bot
- whatsup
- Hi
- Hello
- Heya

## intent:refuse
- no
- No
- Nopes
- nopes
- i'm afraid no
- no sorry
- no thanks
- sorry, not possible
- nevermind
- no, i am fine
- not really
- any other option?
- no, not really
- no, not for me
- not possible
- leave it

## intent:thanks
- thanks
- thanx
- thank you
- thank you so much
- thanks!
- cheers
- thanks a lot
- thanks a ton
- Thanks
- perfect, thanks
- cool, thanks
- ok thanks
- cool. thanks
- great. thanks

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [American](cuisine) restaurants
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in the [New Delhi]{"entity": "location", "value": "Delhi"}
- show me a [Mexican](cuisine) place in the [Jaipur](location)
- i am looking for an [North Indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- anywhere in the [Hyderabad](location)
- I am looking for [South Indian](cuisine) food
- I am looking a restaurant in [Kolkata](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese](cuisine)
- [Pune](location)
- Oh, sorry, in [Noida](location)
- in [Delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [Italian](cuisine)
- [Indore](location) [North Indian](cuisine) restaurant
- please help me to find restaurants in [Pune](location)
- Please find me a restaurantin [Bangalore](location)
- [Mumbai](location)
- show me restaurants
- please find me [Chinese](cuisine) restaurant in [Delhi](location)
- can you find me a [Chinese](cuisine) restaurant
- [Delhi](location)
- please find me a restaurant in [Ahmedabad](location)
- please show me a few [Italian](cuisine) restaurants in [Bangalore](location)
- [Bangalore](location)
- [Mexican](cuisine)
- [Hyderabad](location)
- [Lesser than 300](budget)
- [300 to 700](budget)
- [More than 700](budget)
- [Noida](location)
- [Bangalore](location)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [300 to 700](budget)
- [Kolkata](location)

## intent:ask_email
- can u send me at the mail [test-123.456@dom.123.co.in](email)?
- please share these results with me on email
- email address - [test.some@gmail.co.in](email). Mail this list.- email me at [email-123@gmail.com](email)
- mail me the results at [emial@domain.io](email)
- send these restaurant names to me
- My email address is- [email-abc_123@abc.com.edu](email).
- Send it to mail
- can u mail this info to [abc@abc.com](email)?
- my email address [email.123-abc@domain.123.com](email)
- please mail me the output to [123-email@domain.co.in](email)
- send to [abc-email@abc.com](email)
- send this to [abc_123-email@abc123.com](email)
- can u share this info over mail?
- please send this to [email.123@123.456.com](email)
- [abhinav4972@gmail.com](email)
- mail me the restaurant list
- Send the list to [123@domain.net](email)
- can u drop me a mail?
- [abhinav4972@gmail.com](email)

## synonym:Ahmedabad
- Ahemdabad

## synonym:Allahabad
- Pyagaraj
- allahabad
- alahbad

## synonym:Bangalore
- Bengaluru
- Bangalor
- Bangallore
- bangalore

## synonym:Belgaum
- Belagavi

## synonym:Bhubaneswar
- bhuvaneshwar
- bhubaneshwar
- bhubanevar
- bhuwaneshwar
- bhuvaneswar

## synonym:Chennai
- Chenai
- Madras
- chennai

## synonym:Delhi NCR
- New Delhi
- Delhi
- Deli
- Dilli
- Newdelhi
- newdelhi

## synonym:Guwahati
- guwahati
- guvahati

## synonym:Gwalior
- gwalior
- gvalior

## synonym:Kochi
- Cochin
- kochi

## synonym:Kolkata
- kolkata
- Calcutta
- Calcuta

## synonym:Mangalore
- mangalore
- mangaluru

## synonym:Mumbai
- Bombay
- Purani mumbai
- mumbai
- bombay

## synonym:Mysore
- mysuru
- mysore

## synonym:Pondicherry
- Puducherry
- pondicherry

## synonym:Thiruvananthapuram
- trivandrum
- Trivandrum
- thiruvananthapuram

## synonym:Visakhapatnam
- Vizag
- vizag
- visakhapatnam

## synonym:chinese
- chines
- Chinese
- Chines
- chinese

## synonym:mid
- moderate

## synonym:vegetarian
- veggie
- vegg

## regex:email
- ([\w\.-]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)

## lookup:location
- Ahmedabad
- Bangalore
- Chennai
- Delhi
- Hyderabad
- Kolkata
- Mumbai
- Pune
- Agra
- Ajmer
- Aligarh
- Allahabad
- Amravati
- Amritsar
- Asansol
- Bareilly
- Belgaum
- Bhavnagar
- Bhiwandi
- Bhopal
- Bhubaneswar
- Bikaner
- Chandigarh
- Coimbatore
- Nagpur
- Cuttack
- Dehradun
- Dhanbad
- Durgapur
- Erode
- Faridabad
- Firozabad
- Gulbarga
- Guntur
- Gwalior
- Gurgaon
- Guwahati
- Indore
- Jabalpur
- Jaipur
- Jalandhar
- Jammu
- Jamnagar
- Jamshedpur
- Jhansi
- Jodhpur
- Kakinada
- Kannur
- Kanpur
- Kochi
- Kottayam
- Kolhapur
- Kollam
- Kozhikode
- Kurnool
- Lucknow
- Ludhiana
- Madurai
- Malappuram
- Mathura
- Goa
- Mangalore
- Meerut
- Moradabad
- Mysore
- Nanded
- Nashik
- Nellore
- Noida
- Palakkad
- Patna
- Pondicherry
- Raipur
- Rajkot
- Rajahmundry
- Ranchi
- Rourkela
- Sangli
- Siliguri
- Solapur
- Srinagar
- Surat
- Thiruvananthapuram
- Thrissur
- Tiruchirappalli
- Tirunelveli
- Tiruppur
- Tiruvannamalai
- Ujjain
- Bijapur
- Vadodara
- Varanasi
- Vijayawada
- Visakhapatnam
- Vellore
- Warangal
